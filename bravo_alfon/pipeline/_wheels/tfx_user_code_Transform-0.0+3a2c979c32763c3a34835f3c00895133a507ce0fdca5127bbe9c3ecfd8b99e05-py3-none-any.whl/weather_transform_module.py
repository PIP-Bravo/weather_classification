import tensorflow as tf

CLASS_NAMES = ["Cloudy", "Rain", "Shine", "Sunrise"]
IMG_SIZE = (128, 128)

def preprocessing_fn(inputs):
    image_bytes = inputs['image']
    label_str = inputs['label']

    def process_single_image(img_bytes):
        img = tf.io.decode_image(
            tf.reshape(img_bytes, []),
            channels=3, 
            expand_animations=False
        )
        img.set_shape([None, None, 3])
        img = tf.image.resize(img, IMG_SIZE)
        img = tf.cast(img, tf.float32) / 255.0
        return img

    images = tf.map_fn(
        process_single_image,
        image_bytes,
        fn_output_signature=tf.TensorSpec(shape=(*IMG_SIZE, 3), dtype=tf.float32)
    )

    table = tf.lookup.StaticHashTable(
        initializer=tf.lookup.KeyValueTensorInitializer(
            keys=tf.constant(CLASS_NAMES),
            values=tf.constant(list(range(len(CLASS_NAMES))), dtype=tf.int64),
        ),
        default_value=-1
    )
    labels = table.lookup(label_str)

    return {
        'image_xf': images,
        'label_xf': labels
    }
